<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hotel extends Model
{
    protected $fillable = [
        'name',
        'city',
        'distance',
        'star_rating',
        'description',
        'status',
        'image',
    ];

    protected $appends = [
        'image_url',
    ];

    public function images()
    {
        return $this->hasMany(HotelImage::class);
    }

    public function getImageUrlAttribute(): ?string
    {
        if (!$this->image) {
            return null;
        }

        if (str_starts_with($this->image, 'http://') || str_starts_with($this->image, 'https://')) {
            return $this->image;
        }

        if (!str_contains($this->image, '/')) {
            return asset('assets/images/hotels/' . $this->image);
        }

        return asset($this->image);
    }
}
