<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        \Illuminate\Database\Eloquent\Relations\Relation::morphMap([
            'hajj'          => \App\Models\HajjPackage::class,
            'umrah'         => \App\Models\UmrahPackage::class,
            'domestic'      => \App\Models\DomesticPackage::class,
            'international' => \App\Models\InternationalPackage::class,
            'package'       => \App\Models\Package::class,
        ]);
    }
}
