<?php

require __DIR__ . '/../vendor/autoload.php';
$app = require_once __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\PackageBooking;
use App\Models\User;
use App\Http\Controllers\Api\PackageBookingController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

$user = User::first();
if (!$user) {
    echo "No user found\n";
    exit;
}

Auth::setUser($user);

$controller = new PackageBookingController();
$request = Request::create('/api/package-bookings', 'GET');

$response = $controller->index($request);
echo "INDEX RESPONSE (for User {$user->id}):\n";
echo $response->getContent() . "\n\n";

$myBooking = PackageBooking::where('user_id', $user->id)->first();
if ($myBooking) {
    $showResp = $controller->show($myBooking->id);
    echo "SHOW OWN BOOKING (ID {$myBooking->id}):\n";
    echo $showResp->getContent() . "\n\n";
}

$otherBooking = PackageBooking::where('user_id', '!=', $user->id)->first();
if ($otherBooking) {
    $otherResp = $controller->show($otherBooking->id);
    echo "SHOW OTHER USER BOOKING (ID {$otherBooking->id}):\n";
    echo $otherResp->getContent() . "\n\n";
} else {
    echo "No other user booking exists to test restriction.\n";
}
