<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class VisaCountry extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'country_name',
        'country_code',
        'flag',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    public function visaTypes()
    {
        return $this->hasMany(VisaType::class);
    }

    // Convenience accessor: $country->flag_url
    public function getFlagUrlAttribute()
    {
        return $this->flag ? asset('assets/images/visa_flags/' . $this->flag) : null;
    }

    // Convenience: standard visa type (matches seeder logic)
    public function standardVisaType()
    {
        return $this->hasOne(VisaType::class)->where('visa_name', 'Standard');
    }
}
