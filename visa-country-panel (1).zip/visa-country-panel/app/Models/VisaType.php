<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VisaType extends Model
{
    use HasFactory;

    protected $fillable = [
        'visa_country_id',
        'visa_name',
        'b2b_rate',
        'visa_fee',
        'process_time',
        'requirements',
        'notes',
        'is_active',
    ];

    protected $casts = [
        'requirements' => 'array',
        'is_active'    => 'boolean',
    ];

    public function country()
    {
        return $this->belongsTo(VisaCountry::class, 'visa_country_id');
    }
}
