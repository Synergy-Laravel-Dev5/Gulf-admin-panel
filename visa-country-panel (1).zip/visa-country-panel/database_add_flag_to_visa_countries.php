<?php
// Run: php artisan make:migration add_flag_to_visa_countries_table
// then paste this content in, and run: php artisan migrate

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('visa_countries', function (Blueprint $table) {
            $table->string('flag')->nullable()->after('country_code');
        });
    }

    public function down(): void
    {
        Schema::table('visa_countries', function (Blueprint $table) {
            $table->dropColumn('flag');
        });
    }
};
