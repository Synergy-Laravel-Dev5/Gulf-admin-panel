<?php
// Run: php artisan make:migration add_soft_deletes_to_visa_countries_table
// then paste this content in, and run: php artisan migrate
// (Skip this if visa_countries table already has a deleted_at column.)

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('visa_countries', function (Blueprint $table) {
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::table('visa_countries', function (Blueprint $table) {
            $table->dropSoftDeletes();
        });
    }
};
