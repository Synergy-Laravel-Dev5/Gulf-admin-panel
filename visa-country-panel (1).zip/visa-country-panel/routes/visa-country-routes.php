<?php

use App\Http\Controllers\VisaCountryController;
use Illuminate\Support\Facades\Route;

// Paste this block inside your web.php (same style as your UserController routes)

Route::controller(VisaCountryController::class)
    ->prefix('visa-country')
    ->group(function () {
        Route::get('/', 'index')->name('visa-country.index');
        Route::get('/create', 'create')->name('visa-country.create');
        Route::post('/store', 'store')->name('visa-country.store');
        Route::get('/edit/{id}', 'edit')->name('visa-country.edit');
        Route::put('/update/{id}', 'update')->name('visa-country.update');
        Route::delete('/delete/{id}', 'destroy')->name('visa-country.delete');
        Route::get('/trash', 'trash')->name('visa-country.trash');
        Route::get('/restore/{id}', 'restore')->name('visa-country.restore');
    });
